import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: any | null;
  loading: boolean;
  signIn: (email: string, password: string, method?: string) => Promise<{ error?: any }>;
  signUp: (email: string, password: string, fullName: string) => Promise<{ error?: any }>;
  signInWithGoogle: () => Promise<{ error?: any }>;
  signOut: () => Promise<void>;
  logAuthAttempt: (email: string, success: boolean, method: string, failureReason?: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Function to get user IP and user agent
  const getClientInfo = () => {
    return {
      userAgent: navigator.userAgent,
      // In a real implementation, you would get the real IP from the server
      ipAddress: '127.0.0.1' // Placeholder for demo
    };
  };

  // Log authentication attempts
  const logAuthAttempt = async (email: string, success: boolean, method: string, failureReason?: string) => {
    try {
      const clientInfo = getClientInfo();
      await supabase.from('auth_logs').insert({
        user_id: user?.id || null,
        email,
        ip_address: clientInfo.ipAddress,
        user_agent: clientInfo.userAgent,
        auth_method: method as any,
        success,
        failure_reason: failureReason || null
      });
    } catch (error) {
      console.error('Error logging auth attempt:', error);
    }
  };

  // Fetch user profile
  const fetchProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', userId)
        .single();
      
      if (error) throw error;
      setProfile(data);
    } catch (error) {
      console.error('Error fetching profile:', error);
    }
  };

  // Sign in with email/password
  const signIn = async (email: string, password: string, method = 'encrypted') => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        await logAuthAttempt(email, false, method, error.message);
        return { error };
      }

      await logAuthAttempt(email, true, method);
      toast({
        title: "¡Inicio de sesión exitoso!",
        description: "Bienvenido al sistema de inventario automotriz",
      });

      return { error: null };
    } catch (error: any) {
      await logAuthAttempt(email, false, method, error.message);
      return { error };
    }
  };

  // Sign up with email/password
  const signUp = async (email: string, password: string, fullName: string) => {
    try {
      const redirectUrl = `${window.location.origin}/`;
      
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: redirectUrl,
          data: {
            full_name: fullName
          }
        }
      });

      if (error) {
        await logAuthAttempt(email, false, 'encrypted', error.message);
        return { error };
      }

      await logAuthAttempt(email, true, 'encrypted');
      toast({
        title: "¡Registro exitoso!",
        description: "Por favor revisa tu email para confirmar tu cuenta",
      });

      return { error: null };
    } catch (error: any) {
      await logAuthAttempt(email, false, 'encrypted', error.message);
      return { error };
    }
  };

  // Sign in with Google
  const signInWithGoogle = async () => {
    try {
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/`
        }
      });

      if (error) {
        await logAuthAttempt('', false, 'google', error.message);
        return { error };
      }

      return { error: null };
    } catch (error: any) {
      await logAuthAttempt('', false, 'google', error.message);
      return { error };
    }
  };

  // Sign out
  const signOut = async () => {
    try {
      await supabase.auth.signOut();
      setUser(null);
      setSession(null);
      setProfile(null);
      toast({
        title: "Sesión cerrada",
        description: "Has cerrado sesión exitosamente",
      });
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          // Defer profile fetching to avoid blocking auth state updates
          setTimeout(() => {
            fetchProfile(session.user.id);
          }, 0);
        } else {
          setProfile(null);
        }
        
        setLoading(false);
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchProfile(session.user.id);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const value = {
    user,
    session,
    profile,
    loading,
    signIn,
    signUp,
    signInWithGoogle,
    signOut,
    logAuthAttempt
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};