import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Skeleton } from '@/components/ui/skeleton';

interface AuthGuardProps {
  children: React.ReactNode;
  requiredRole?: 'Visitante' | 'Administrador' | 'Super-administrador';
  redirectTo?: string;
}

export const AuthGuard = ({ children, requiredRole, redirectTo = '/auth' }: AuthGuardProps) => {
  const { user, profile, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading) {
      if (!user) {
        navigate(redirectTo);
        return;
      }

      if (requiredRole && profile?.role !== requiredRole) {
        // Check for role hierarchy
        const roleHierarchy = {
          'Super-administrador': 3,
          'Administrador': 2,
          'Visitante': 1
        };

        const userRoleLevel = roleHierarchy[profile?.role as keyof typeof roleHierarchy] || 0;
        const requiredRoleLevel = roleHierarchy[requiredRole as keyof typeof roleHierarchy] || 0;

        if (userRoleLevel < requiredRoleLevel) {
          navigate('/');
          return;
        }
      }
    }
  }, [user, profile, loading, requiredRole, redirectTo, navigate]);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="space-y-4">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-48" />
          <Skeleton className="h-4 w-32" />
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  if (requiredRole && profile?.role !== requiredRole) {
    const roleHierarchy = {
      'Super-administrador': 3,
      'Administrador': 2,
      'Visitante': 1
    };

    const userRoleLevel = roleHierarchy[profile?.role as keyof typeof roleHierarchy] || 0;
    const requiredRoleLevel = roleHierarchy[requiredRole as keyof typeof roleHierarchy] || 0;

    if (userRoleLevel < requiredRoleLevel) {
      return null;
    }
  }

  return <>{children}</>;
};