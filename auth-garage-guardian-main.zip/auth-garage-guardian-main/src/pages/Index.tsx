import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Car, 
  Shield, 
  Users, 
  Activity, 
  LogIn,
  UserPlus,
  BarChart3
} from 'lucide-react';

const Index = () => {
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();

  // Redirect authenticated users based on their role
  useEffect(() => {
    if (user && profile) {
      if (profile.role === 'Super-administrador') {
        navigate('/dashboard');
      } else {
        navigate('/inventory');
      }
    }
  }, [user, profile, navigate]);

  const handleSignOut = async () => {
    await signOut();
  };

  if (user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground">Redirigiendo...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Car className="h-8 w-8 text-primary" />
              <span className="ml-2 text-xl font-bold">AutoInventory</span>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={() => navigate('/auth')}>
                <LogIn className="h-4 w-4 mr-2" />
                Iniciar Sesión
              </Button>
              <Button onClick={() => navigate('/auth')}>
                <UserPlus className="h-4 w-4 mr-2" />
                Registrarse
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center space-y-8">
          <div className="space-y-4">
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
              Sistema de Inventario
              <span className="block text-primary">Automotriz</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Plataforma completa de gestión vehicular con múltiples capas de seguridad, 
              autenticación robusta y sistema de auditoría avanzado.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" onClick={() => navigate('/auth')}>
              <LogIn className="h-5 w-5 mr-2" />
              Acceder al Sistema
            </Button>
            <Button size="lg" variant="outline" onClick={() => navigate('/inventory')}>
              <Car className="h-5 w-5 mr-2" />
              Ver Catálogo Público
            </Button>
          </div>
        </div>

        {/* Features Section */}
        <div className="mt-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Características del Sistema</h2>
            <p className="text-muted-foreground">
              Implementación de arquitectura cliente-servidor con múltiples métodos de autenticación
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Authentication Methods */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-6 w-6 text-blue-500" />
                  Métodos de Autenticación
                </CardTitle>
                <CardDescription>
                  Múltiples capas de seguridad implementadas
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2">
                  <Badge variant="destructive">Básica</Badge>
                  <span className="text-sm">Sin cifrado (educativo)</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="default">Cifrada</Badge>
                  <span className="text-sm">Hash seguro</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">Google</Badge>
                  <span className="text-sm">OAuth 2.0</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className="bg-green-500">MFA</Badge>
                  <span className="text-sm">Doble factor</span>
                </div>
              </CardContent>
            </Card>

            {/* User Roles */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-6 w-6 text-green-500" />
                  Roles de Usuario
                </CardTitle>
                <CardDescription>
                  Control de acceso granular por roles
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-1">
                  <Badge variant="secondary">Visitante</Badge>
                  <p className="text-sm text-muted-foreground">Consulta pública del catálogo</p>
                </div>
                <div className="space-y-1">
                  <Badge className="bg-blue-500">Administrador</Badge>
                  <p className="text-sm text-muted-foreground">CRUD completo del inventario</p>
                </div>
                <div className="space-y-1">
                  <Badge className="bg-red-500">Super Admin</Badge>
                  <p className="text-sm text-muted-foreground">Gestión de usuarios + auditoría</p>
                </div>
              </CardContent>
            </Card>

            {/* Security Features */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-6 w-6 text-orange-500" />
                  Seguridad Avanzada
                </CardTitle>
                <CardDescription>
                  Protección contra ataques y monitoreo
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-1">
                  <div className="text-sm font-medium">Anti-Brute Force</div>
                  <p className="text-sm text-muted-foreground">Exponential Backoff</p>
                </div>
                <div className="space-y-1">
                  <div className="text-sm font-medium">JWT con expiración</div>
                  <p className="text-sm text-muted-foreground">Sesiones de 2 minutos</p>
                </div>
                <div className="space-y-1">
                  <div className="text-sm font-medium">Auditoría completa</div>
                  <p className="text-sm text-muted-foreground">Logs detallados de actividad</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Technology Stack */}
        <div className="mt-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Arquitectura del Sistema</h2>
            <p className="text-muted-foreground">
              Tecnologías modernas para una plataforma robusta y escalable
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Frontend (Cliente)</CardTitle>
                <CardDescription>Interfaz de usuario moderna y responsive</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-2">
                  <Badge variant="outline">React</Badge>
                  <span className="text-sm">Framework de UI</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">TypeScript</Badge>
                  <span className="text-sm">Tipado estático</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Tailwind CSS</Badge>
                  <span className="text-sm">Estilos utilitarios</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Vite</Badge>
                  <span className="text-sm">Build tool moderno</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Backend (Servidor)</CardTitle>
                <CardDescription>Base de datos y API seguras</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Supabase</Badge>
                  <span className="text-sm">Backend as a Service</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">PostgreSQL</Badge>
                  <span className="text-sm">Base de datos relacional</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Row Level Security</Badge>
                  <span className="text-sm">Seguridad de datos</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Edge Functions</Badge>
                  <span className="text-sm">Lógica del servidor</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
