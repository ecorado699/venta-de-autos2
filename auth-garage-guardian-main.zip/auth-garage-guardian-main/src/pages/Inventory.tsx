import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { AuthGuard } from '@/components/AuthGuard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { 
  Car, 
  Plus, 
  Edit, 
  Trash2, 
  Eye,
  Filter,
  DollarSign,
  Calendar,
  Gauge
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Vehicle {
  id: string;
  marca: string;
  modelo: string;
  año: number;
  precio: number;
  estado: 'Disponible' | 'Vendido' | 'En mantenimiento';
  kilometraje: number;
  color: string;
  deleted_at: string | null;
  created_at: string;
  updated_at: string;
}

const Inventory = () => {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [filter, setFilter] = useState('all');

  // Form state
  const [formData, setFormData] = useState({
    marca: '',
    modelo: '',
    año: new Date().getFullYear(),
    precio: 0,
    estado: 'Disponible' as Vehicle['estado'],
    kilometraje: 0,
    color: ''
  });

  // Fetch vehicles
  const fetchVehicles = async () => {
    try {
      setLoading(true);
      let query = supabase
        .from('vehicles')
        .select('*')
        .is('deleted_at', null) // Only show non-deleted vehicles
        .order('created_at', { ascending: false });

      if (filter !== 'all') {
        query = query.eq('estado', filter as Vehicle['estado']);
      }

      const { data, error } = await query;

      if (error) throw error;
      setVehicles(data || []);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "No se pudieron cargar los vehículos",
      });
    } finally {
      setLoading(false);
    }
  };

  // Add vehicle
  const addVehicle = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const { error } = await supabase
        .from('vehicles')
        .insert([formData]);

      if (error) throw error;

      toast({
        title: "Vehículo agregado",
        description: "El vehículo ha sido agregado exitosamente",
      });

      setIsAddDialogOpen(false);
      resetForm();
      fetchVehicles();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "No se pudo agregar el vehículo",
      });
    }
  };

  // Update vehicle
  const updateVehicle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingVehicle) return;

    try {
      const { error } = await supabase
        .from('vehicles')
        .update(formData)
        .eq('id', editingVehicle.id);

      if (error) throw error;

      toast({
        title: "Vehículo actualizado",
        description: "El vehículo ha sido actualizado exitosamente",
      });

      setEditingVehicle(null);
      resetForm();
      fetchVehicles();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "No se pudo actualizar el vehículo",
      });
    }
  };

  // Soft delete vehicle
  const deleteVehicle = async (vehicleId: string) => {
    try {
      const { error } = await supabase
        .from('vehicles')
        .update({ deleted_at: new Date().toISOString() })
        .eq('id', vehicleId);

      if (error) throw error;

      toast({
        title: "Vehículo eliminado",
        description: "El vehículo ha sido eliminado exitosamente",
      });

      fetchVehicles();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "No se pudo eliminar el vehículo",
      });
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      marca: '',
      modelo: '',
      año: new Date().getFullYear(),
      precio: 0,
      estado: 'Disponible',
      kilometraje: 0,
      color: ''
    });
  };

  // Open edit dialog
  const openEditDialog = (vehicle: Vehicle) => {
    setEditingVehicle(vehicle);
    setFormData({
      marca: vehicle.marca,
      modelo: vehicle.modelo,
      año: vehicle.año,
      precio: vehicle.precio,
      estado: vehicle.estado,
      kilometraje: vehicle.kilometraje,
      color: vehicle.color
    });
  };

  // Close edit dialog
  const closeEditDialog = () => {
    setEditingVehicle(null);
    resetForm();
  };

  const getStatusBadge = (status: Vehicle['estado']) => {
    switch (status) {
      case 'Disponible':
        return <Badge className="bg-green-500">Disponible</Badge>;
      case 'Vendido':
        return <Badge className="bg-blue-500">Vendido</Badge>;
      case 'En mantenimiento':
        return <Badge className="bg-yellow-500">En mantenimiento</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const canManageVehicles = profile?.role === 'Administrador' || profile?.role === 'Super-administrador';

  useEffect(() => {
    fetchVehicles();
  }, [filter]);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
          <p className="mt-4 text-muted-foreground">Cargando inventario...</p>
        </div>
      </div>
    );
  }

  const VehicleForm = ({ onSubmit, submitText }: { onSubmit: (e: React.FormEvent) => void; submitText: string }) => (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="marca">Marca</Label>
          <Input
            id="marca"
            value={formData.marca}
            onChange={(e) => setFormData(prev => ({ ...prev, marca: e.target.value }))}
            placeholder="Toyota, Ford, Chevrolet..."
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="modelo">Modelo</Label>
          <Input
            id="modelo"
            value={formData.modelo}
            onChange={(e) => setFormData(prev => ({ ...prev, modelo: e.target.value }))}
            placeholder="Camry, F-150, Silverado..."
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="año">Año</Label>
          <Input
            id="año"
            type="number"
            min="1900"
            max={new Date().getFullYear() + 1}
            value={formData.año}
            onChange={(e) => setFormData(prev => ({ ...prev, año: parseInt(e.target.value) }))}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="precio">Precio</Label>
          <Input
            id="precio"
            type="number"
            min="0"
            step="0.01"
            value={formData.precio}
            onChange={(e) => setFormData(prev => ({ ...prev, precio: parseFloat(e.target.value) }))}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="estado">Estado</Label>
          <Select value={formData.estado} onValueChange={(value) => setFormData(prev => ({ ...prev, estado: value as Vehicle['estado'] }))}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Disponible">Disponible</SelectItem>
              <SelectItem value="Vendido">Vendido</SelectItem>
              <SelectItem value="En mantenimiento">En mantenimiento</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="kilometraje">Kilometraje</Label>
          <Input
            id="kilometraje"
            type="number"
            min="0"
            value={formData.kilometraje}
            onChange={(e) => setFormData(prev => ({ ...prev, kilometraje: parseInt(e.target.value) }))}
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="color">Color</Label>
        <Input
          id="color"
          value={formData.color}
          onChange={(e) => setFormData(prev => ({ ...prev, color: e.target.value }))}
          placeholder="Blanco, Negro, Rojo..."
          required
        />
      </div>

      <Button type="submit" className="w-full">
        {submitText}
      </Button>
    </form>
  );

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Inventario Automotriz</h1>
            <p className="text-muted-foreground">
              {canManageVehicles 
                ? 'Gestiona el inventario completo de vehículos' 
                : 'Consulta el catálogo público de vehículos'
              }
            </p>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="outline">
              {profile?.role}
            </Badge>
            {canManageVehicles && (
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="flex items-center gap-2">
                    <Plus className="h-4 w-4" />
                    Agregar Vehículo
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Agregar Nuevo Vehículo</DialogTitle>
                    <DialogDescription>
                      Completa la información del nuevo vehículo
                    </DialogDescription>
                  </DialogHeader>
                  <VehicleForm onSubmit={addVehicle} submitText="Agregar Vehículo" />
                </DialogContent>
              </Dialog>
            )}
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span className="text-sm font-medium">Filtrar por estado:</span>
          </div>
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="Disponible">Disponible</SelectItem>
              <SelectItem value="Vendido">Vendido</SelectItem>
              <SelectItem value="En mantenimiento">En mantenimiento</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Vehicle Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {vehicles.map((vehicle) => (
            <Card key={vehicle.id} className="overflow-hidden">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Car className="h-5 w-5" />
                      {vehicle.marca} {vehicle.modelo}
                    </CardTitle>
                    <CardDescription>{vehicle.año}</CardDescription>
                  </div>
                  {getStatusBadge(vehicle.estado)}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">
                      ${vehicle.precio.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Gauge className="h-4 w-4 text-muted-foreground" />
                    <span>{vehicle.kilometraje.toLocaleString()} km</span>
                  </div>
                </div>
                
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-4 h-4 rounded-full border-2" style={{ backgroundColor: vehicle.color.toLowerCase() }}></div>
                  <span>{vehicle.color}</span>
                </div>

                {canManageVehicles && (
                  <div className="flex gap-2 pt-2">
                    <Dialog open={editingVehicle?.id === vehicle.id} onOpenChange={(open) => open ? openEditDialog(vehicle) : closeEditDialog()}>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" className="flex-1">
                          <Edit className="h-4 w-4 mr-1" />
                          Editar
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-md">
                        <DialogHeader>
                          <DialogTitle>Editar Vehículo</DialogTitle>
                          <DialogDescription>
                            Actualiza la información del vehículo
                          </DialogDescription>
                        </DialogHeader>
                        <VehicleForm onSubmit={updateVehicle} submitText="Actualizar Vehículo" />
                      </DialogContent>
                    </Dialog>

                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive" size="sm">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>¿Eliminar vehículo?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Esta acción eliminará el vehículo "{vehicle.marca} {vehicle.modelo}" del inventario. 
                            Esta acción no se puede deshacer.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => deleteVehicle(vehicle.id)}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          >
                            Eliminar
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {vehicles.length === 0 && (
          <div className="text-center py-12">
            <Car className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium">No hay vehículos disponibles</h3>
            <p className="text-muted-foreground mb-4">
              {filter === 'all' 
                ? 'No se encontraron vehículos en el inventario' 
                : `No hay vehículos con estado "${filter}"`
              }
            </p>
            {canManageVehicles && (
              <Button onClick={() => setIsAddDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Agregar primer vehículo
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Inventory;