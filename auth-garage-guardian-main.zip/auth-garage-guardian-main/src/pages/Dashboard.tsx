import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { AuthGuard } from '@/components/AuthGuard';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  Activity, 
  Shield, 
  AlertTriangle,
  Eye,
  Calendar,
  MapPin,
  Globe
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface AuthLog {
  id: string;
  user_id: string | null;
  email: string;
  ip_address: unknown;
  user_agent: string;
  auth_method: string;
  success: boolean;
  failure_reason: string | null;
  created_at: string;
}

interface RequestLog {
  id: string;
  user_id: string | null;
  endpoint: string;
  method: string;
  ip_address: unknown;
  user_agent: string;
  response_status: number;
  processing_time_ms: number;
  created_at: string;
}

interface User {
  id: string;
  email: string;
  full_name: string;
  role: 'Visitante' | 'Administrador' | 'Super-administrador';
  is_active: boolean;
  created_at: string;
}

const Dashboard = () => {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [authLogs, setAuthLogs] = useState<AuthLog[]>([]);
  const [requestLogs, setRequestLogs] = useState<RequestLog[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch authentication logs
  const fetchAuthLogs = async () => {
    try {
      const { data, error } = await supabase
        .from('auth_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setAuthLogs(data || []);
    } catch (error) {
      console.error('Error fetching auth logs:', error);
    }
  };

  // Fetch request logs
  const fetchRequestLogs = async () => {
    try {
      const { data, error } = await supabase
        .from('request_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setRequestLogs(data || []);
    } catch (error) {
      console.error('Error fetching request logs:', error);
    }
  };

  // Fetch users
  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setUsers(data || []);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  // Update user role
  const updateUserRole = async (userId: string, newRole: 'Visitante' | 'Administrador' | 'Super-administrador') => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ role: newRole })
        .eq('user_id', userId);

      if (error) throw error;

      toast({
        title: "Rol actualizado",
        description: `El rol del usuario ha sido actualizado a ${newRole}`,
      });

      fetchUsers(); // Refresh users list
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "No se pudo actualizar el rol",
      });
    }
  };

  // Toggle user active status
  const toggleUserStatus = async (userId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_active: !currentStatus })
        .eq('user_id', userId);

      if (error) throw error;

      toast({
        title: "Estado actualizado",
        description: `El usuario ha sido ${!currentStatus ? 'activado' : 'desactivado'}`,
      });

      fetchUsers(); // Refresh users list
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "No se pudo actualizar el estado",
      });
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([
        fetchAuthLogs(),
        fetchRequestLogs(),
        fetchUsers()
      ]);
      setLoading(false);
    };

    loadData();
  }, []);

  const getAuthMethodBadge = (method: string) => {
    switch (method) {
      case 'basic':
        return <Badge variant="destructive">Básica</Badge>;
      case 'encrypted':
        return <Badge variant="default">Cifrada</Badge>;
      case 'google':
        return <Badge variant="secondary">Google</Badge>;
      case 'mfa':
        return <Badge className="bg-green-500">MFA</Badge>;
      default:
        return <Badge variant="outline">{method}</Badge>;
    }
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'Super-administrador':
        return <Badge className="bg-red-500">Super Admin</Badge>;
      case 'Administrador':
        return <Badge className="bg-blue-500">Admin</Badge>;
      case 'Visitante':
        return <Badge variant="secondary">Visitante</Badge>;
      default:
        return <Badge variant="outline">{role}</Badge>;
    }
  };

  // Calculate statistics
  const totalLogins = authLogs.length;
  const successfulLogins = authLogs.filter(log => log.success).length;
  const failedLogins = authLogs.filter(log => !log.success).length;
  const uniqueUsers = new Set(authLogs.map(log => log.email)).size;

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
          <p className="mt-4 text-muted-foreground">Cargando dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <AuthGuard requiredRole="Super-administrador">
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Dashboard de Auditoría</h1>
              <p className="text-muted-foreground">
                Monitoreo de seguridad y actividad del sistema
              </p>
            </div>
            <Badge className="bg-green-500">
              Super Administrador: {profile?.full_name}
            </Badge>
          </div>

          {/* Statistics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total de Inicios</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalLogins}</div>
                <p className="text-xs text-muted-foreground">
                  Intentos de autenticación
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Exitosos</CardTitle>
                <Shield className="h-4 w-4 text-green-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{successfulLogins}</div>
                <p className="text-xs text-muted-foreground">
                  {totalLogins > 0 ? Math.round((successfulLogins / totalLogins) * 100) : 0}% de éxito
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Fallidos</CardTitle>
                <AlertTriangle className="h-4 w-4 text-destructive" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-destructive">{failedLogins}</div>
                <p className="text-xs text-muted-foreground">
                  Intentos de acceso denegados
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Usuarios Únicos</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{uniqueUsers}</div>
                <p className="text-xs text-muted-foreground">
                  Usuarios diferentes
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Tabs for different views */}
          <Tabs defaultValue="auth-logs" className="space-y-4">
            <TabsList>
              <TabsTrigger value="auth-logs">Logs de Autenticación</TabsTrigger>
              <TabsTrigger value="request-logs">Logs de Requests</TabsTrigger>
              <TabsTrigger value="users">Gestión de Usuarios</TabsTrigger>
            </TabsList>

            <TabsContent value="auth-logs" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Logs de Autenticación
                  </CardTitle>
                  <CardDescription>
                    Registro detallado de todos los intentos de autenticación
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {authLogs.map((log) => (
                      <div
                        key={log.id}
                        className={`p-4 rounded-lg border ${
                          log.success 
                            ? 'border-green-200 bg-green-50' 
                            : 'border-red-200 bg-red-50'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{log.email}</span>
                              {getAuthMethodBadge(log.auth_method)}
                              {log.success ? (
                                <Badge className="bg-green-500">Exitoso</Badge>
                              ) : (
                                <Badge variant="destructive">Fallido</Badge>
                              )}
                            </div>
                            {!log.success && log.failure_reason && (
                              <p className="text-sm text-red-600">
                                Razón: {log.failure_reason}
                              </p>
                            )}
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <MapPin className="h-3 w-3" />
                                IP: {String(log.ip_address)}
                              </span>
                              <span className="flex items-center gap-1">
                                <Calendar className="h-3 w-3" />
                                {new Date(log.created_at).toLocaleString('es-ES')}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                    {authLogs.length === 0 && (
                      <div className="text-center py-8 text-muted-foreground">
                        No hay logs de autenticación disponibles
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="request-logs" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Logs de Requests
                  </CardTitle>
                  <CardDescription>
                    Registro de actividad y uso de endpoints
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {requestLogs.map((log) => (
                      <div
                        key={log.id}
                        className="p-4 rounded-lg border bg-card"
                      >
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline">{log.method}</Badge>
                              <span className="font-medium">{log.endpoint}</span>
                              <Badge 
                                variant={log.response_status < 400 ? "default" : "destructive"}
                              >
                                {log.response_status}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <MapPin className="h-3 w-3" />
                                IP: {String(log.ip_address)}
                              </span>
                              <span>
                                Tiempo: {log.processing_time_ms}ms
                              </span>
                              <span className="flex items-center gap-1">
                                <Calendar className="h-3 w-3" />
                                {new Date(log.created_at).toLocaleString('es-ES')}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                    {requestLogs.length === 0 && (
                      <div className="text-center py-8 text-muted-foreground">
                        No hay logs de requests disponibles
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="users" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Gestión de Usuarios
                  </CardTitle>
                  <CardDescription>
                    Administración de roles y permisos de usuario
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {users.map((user) => (
                      <div
                        key={user.id}
                        className="p-4 rounded-lg border bg-card"
                      >
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{user.full_name}</span>
                              {getRoleBadge(user.role)}
                              <Badge 
                                variant={user.is_active ? "default" : "secondary"}
                              >
                                {user.is_active ? 'Activo' : 'Inactivo'}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <span>{user.email}</span>
                              <span className="flex items-center gap-1">
                                <Calendar className="h-3 w-3" />
                                Registrado: {new Date(user.created_at).toLocaleDateString('es-ES')}
                              </span>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <select
                              value={user.role}
                              onChange={(e) => updateUserRole(user.id, e.target.value as 'Visitante' | 'Administrador' | 'Super-administrador')}
                              className="px-3 py-1 border rounded text-sm"
                            >
                              <option value="Visitante">Visitante</option>
                              <option value="Administrador">Administrador</option>
                              <option value="Super-administrador">Super-administrador</option>
                            </select>
                            <Button
                              variant={user.is_active ? "destructive" : "default"}
                              size="sm"
                              onClick={() => toggleUserStatus(user.id, user.is_active)}
                            >
                              {user.is_active ? 'Desactivar' : 'Activar'}
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                    {users.length === 0 && (
                      <div className="text-center py-8 text-muted-foreground">
                        No hay usuarios registrados
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </AuthGuard>
  );
};

export default Dashboard;