🚗 Sistema de Autenticación con Arquitectura Cliente-Servidor

Proyecto académico de gestión de inventario automotriz con múltiples métodos de autenticación y medidas de seguridad.

🎯 Objetivo

Desarrollar un sistema que implemente diferentes métodos de autenticación utilizando arquitectura cliente-servidor, simulando vulnerabilidades de seguridad y técnicas de protección, en un contexto de gestión de inventario automotriz.

⚙️ Especificaciones del Sistema
🔹 Arquitectura

Modelo Cliente-Servidor: separación clara entre frontend y backend.

Protocolo de comunicación: HTTP/HTTPS.

Base de datos: almacenamiento de usuarios e inventario.

Servidor: simula el levantamiento de un servidor.

🔹 Inventario Automotriz

El sistema gestiona un inventario de vehículos con los siguientes campos:

ID del vehículo: identificador único.

Marca: Toyota, Ford, Chevrolet, etc.

Modelo: Camry, F-150, Silverado, etc.

Año: año de fabricación.

Precio: valor en moneda local.

Estado: Disponible, Vendido, En mantenimiento.

Kilometraje: kilómetros recorridos.

Color: color del vehículo.

Nota: Actualmente el sistema solo permite listar los vehículos creados en el inventario.

🔑 Métodos de Autenticación

Autenticación Básica (Sin Cifrado)

Usuario y contraseña en texto plano.

Autenticación con Cifrado de Contraseña

Hash con MD5, SHA-256, bcrypt.

Contraseñas almacenadas de forma segura.

Login con Google

Integración con login de Google.

Almacenamiento de datos necesarios para este tipo de login.

Registro de inicios de sesión por usuario.

👥 Roles de Usuario

Visitante

Consulta del catálogo público de vehículos (solo lectura).

Administrador

CRUD completo del inventario automotriz.

Eliminación lógica de registros (borrado suave).

Super-Administrador

Gestión completa de usuarios.

Acceso a tablero de métricas de auditoría y logging.

Todos los privilegios de administrador.

🔐 Funcionalidades de Seguridad
1. Autenticación Multi-Factor (MFA)

Doble factor de autenticación (ejemplo: Duo Security).

Sesiones manejadas con JWT (expiración: 2 minutos).

Implementación de reclamos personalizados.

2. Protección Anti-Brute Force

Exponential Backoff en el login.

Bloqueo por IP ante intentos sospechosos.

Validación mediante:

Red en clase (intentos grupales).

Publicación en internet.

Script de múltiples intentos.

3. Sistema de Auditoría y Logging

Logs de autenticación: intentos exitosos y fallidos, por IP.

Registro de solicitudes por endpoint: estadísticas de uso.

Tablero de auditoría y métricas.

🚀 Estado Actual

✅ Listado de vehículos del inventario.

🔒 Implementación inicial de autenticación.

⚠️ Funcionalidades avanzadas en desarrollo.