-- Create enum types
CREATE TYPE public.vehicle_status AS ENUM ('Disponible', 'Vendido', 'En mantenimiento');
CREATE TYPE public.user_role AS ENUM ('Visitante', 'Administrador', 'Super-administrador');
CREATE TYPE public.auth_method AS ENUM ('basic', 'encrypted', 'google', 'mfa');

-- Create vehicles table
CREATE TABLE public.vehicles (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    marca TEXT NOT NULL,
    modelo TEXT NOT NULL,
    año INTEGER NOT NULL,
    precio DECIMAL(12,2) NOT NULL,
    estado vehicle_status NOT NULL DEFAULT 'Disponible',
    kilometraje INTEGER NOT NULL DEFAULT 0,
    color TEXT NOT NULL,
    deleted_at TIMESTAMP WITH TIME ZONE NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user profiles table
CREATE TABLE public.profiles (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL UNIQUE,
    email TEXT NOT NULL UNIQUE,
    full_name TEXT,
    role user_role NOT NULL DEFAULT 'Visitante',
    is_active BOOLEAN NOT NULL DEFAULT true,
    mfa_enabled BOOLEAN NOT NULL DEFAULT false,
    mfa_secret TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create authentication logs table
CREATE TABLE public.auth_logs (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID,
    email TEXT,
    ip_address INET,
    user_agent TEXT,
    auth_method auth_method NOT NULL,
    success BOOLEAN NOT NULL,
    failure_reason TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create request logs table for audit
CREATE TABLE public.request_logs (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID,
    endpoint TEXT NOT NULL,
    method TEXT NOT NULL,
    ip_address INET,
    user_agent TEXT,
    request_body JSONB,
    response_status INTEGER,
    processing_time_ms INTEGER,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create brute force protection table
CREATE TABLE public.login_attempts (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    ip_address INET NOT NULL,
    email TEXT,
    attempts INTEGER NOT NULL DEFAULT 1,
    last_attempt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    blocked_until TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.auth_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.request_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.login_attempts ENABLE ROW LEVEL SECURITY;

-- Create policies for vehicles (visitors can read, admins can manage)
CREATE POLICY "Visitors can view available vehicles" 
ON public.vehicles 
FOR SELECT 
USING (deleted_at IS NULL);

CREATE POLICY "Admins can manage vehicles" 
ON public.vehicles 
FOR ALL 
USING (
    EXISTS (
        SELECT 1 FROM public.profiles 
        WHERE user_id = auth.uid() 
        AND role IN ('Administrador', 'Super-administrador')
        AND is_active = true
    )
);

-- Create policies for profiles
CREATE POLICY "Users can view their own profile" 
ON public.profiles 
FOR SELECT 
USING (user_id = auth.uid());

CREATE POLICY "Super-admins can manage all profiles" 
ON public.profiles 
FOR ALL 
USING (
    EXISTS (
        SELECT 1 FROM public.profiles 
        WHERE user_id = auth.uid() 
        AND role = 'Super-administrador'
        AND is_active = true
    )
);

-- Create policies for auth logs
CREATE POLICY "Super-admins can view all auth logs" 
ON public.auth_logs 
FOR SELECT 
USING (
    EXISTS (
        SELECT 1 FROM public.profiles 
        WHERE user_id = auth.uid() 
        AND role = 'Super-administrador'
        AND is_active = true
    )
);

-- Create policies for request logs
CREATE POLICY "Super-admins can view all request logs" 
ON public.request_logs 
FOR SELECT 
USING (
    EXISTS (
        SELECT 1 FROM public.profiles 
        WHERE user_id = auth.uid() 
        AND role = 'Super-administrador'
        AND is_active = true
    )
);

-- Create policies for login attempts
CREATE POLICY "System can manage login attempts" 
ON public.login_attempts 
FOR ALL 
USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_vehicles_updated_at
    BEFORE UPDATE ON public.vehicles
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_profiles_updated_at
    BEFORE UPDATE ON public.profiles
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Insert sample vehicles data
INSERT INTO public.vehicles (marca, modelo, año, precio, estado, kilometraje, color) VALUES
('Toyota', 'Camry', 2022, 25000.00, 'Disponible', 15000, 'Blanco'),
('Ford', 'F-150', 2021, 35000.00, 'Disponible', 25000, 'Negro'),
('Chevrolet', 'Silverado', 2023, 40000.00, 'Disponible', 5000, 'Rojo'),
('Honda', 'Civic', 2020, 22000.00, 'Vendido', 30000, 'Azul'),
('Nissan', 'Altima', 2022, 24000.00, 'En mantenimiento', 18000, 'Gris'),
('BMW', '320i', 2023, 45000.00, 'Disponible', 8000, 'Blanco'),
('Mercedes-Benz', 'C-Class', 2022, 50000.00, 'Disponible', 12000, 'Negro'),
('Audi', 'A4', 2021, 42000.00, 'Disponible', 20000, 'Azul');

-- Create function to handle user registration with profile creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (user_id, email, full_name, role)
    VALUES (
        NEW.id, 
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
        'Visitante'
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create trigger for automatic profile creation
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_new_user();